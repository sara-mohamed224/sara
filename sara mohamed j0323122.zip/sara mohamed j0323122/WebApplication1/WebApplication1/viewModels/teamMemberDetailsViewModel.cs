﻿using WebApplication1.Models;

namespace WebApplication1.viewModels
{
    public class teamMemberDetailsViewModel
    {
       public TeamMember TeamMember {  get; set; }
       
        public List <task>tasks { get; set; }
    }
}
