﻿using WebApplication1.Models;

namespace WebApplication1.viewModels
{
    public class TaskDetailsViewModel
    {
        public  task Task { get; set; }
        public TeamMember TeamMember { get; set; }
        public Project Project { get; set; }
    }
}
