﻿using WebApplication1.Models;

namespace WebApplication1.viewModels
{
    public class ProjectDetailsViewModel
    {
        public Project Project { get; set; }
        public ICollection<task>Tasks { get; set; }
    }
}
