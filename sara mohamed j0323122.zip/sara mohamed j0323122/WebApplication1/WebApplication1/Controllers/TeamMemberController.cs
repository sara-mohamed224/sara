﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;
using WebApplication1.viewModels;

namespace WebApplication1.Controllers
{
    public class TeamMemberController : Controller
    {
        IATSContext context = new IATSContext();
        public IActionResult Index()
        {
            var teamMembers = context.TeamMembers.ToList();
            return View(teamMembers);
        }

        public IActionResult Update(int id)
        {
            var teamMember = context.TeamMembers.FirstOrDefault(t => t.Id == id);
            if (teamMember != null)
            {
                return View(teamMember);


            }
            return RedirectToAction("index");

        }
        [HttpPost]
        public IActionResult Update(TeamMember model)
        {
            var teamMember = context.TeamMembers.FirstOrDefault(t => t.Id == model.Id);
            if (teamMember != null)
            {
                teamMember.Name = model.Name;
                teamMember.Email = model.Email;
                teamMember.Role = model.Role;
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(model);

        }
        public IActionResult Delete(int id)
        {
            var teamMember = context.TeamMembers.FirstOrDefault(t => t.Id == id);
            if (teamMember != null)
            {
                context.TeamMembers.Remove(teamMember);
                context.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        public IActionResult Add(int id)
        {
            return View();
        }
        [HttpPost]
        public IActionResult Add(TeamMember model)
        {
            if (model.Name != null && model.Email != null && model.Role != null)
            {
                context.TeamMembers.Add(model);
                context.SaveChanges();
                return RedirectToAction("Index");


            }
            return View(model);


        }

        public IActionResult Details(int id)
        {
            var teamMember = context.TeamMembers.FirstOrDefault(t => t.Id == id);
            if (teamMember != null)
            {
                var taskss = context.tasks.Where(t => t.TeamMemberID == id).ToList();
                var teamMemberDetails = new teamMemberDetailsViewModel() { TeamMember = teamMember, tasks = taskss };
                return View(teamMemberDetails);
            }
            return RedirectToAction("index");


        }
    }
}
