﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;
using WebApplication1.viewModels;

namespace WebApplication1.Controllers
{
    public class TasksController : Controller
    {
        IATSContext context = new IATSContext();
        public IActionResult Index()
        {
            var tasks =context.tasks.ToList();

            return View(tasks);
        }
        public IActionResult Update(int id) {
        var task =context.tasks.FirstOrDefault(t=>t.Id==id);
            if (task != null) { 
            return View(task);
            }
        return RedirectToAction("Index");
        }
        [HttpPost]
        public IActionResult Update( task model) { 
            var task =context.tasks.FirstOrDefault(t=>t.Id== model.Id);
            if (task != null) {
                task.Title = model.Title;
                task.Description=model.Description;
                task.Status = model.Status;
                task.Name = model.Name;
                task.Priority = model.Priority;
                task.DeadLine = model.DeadLine;
                task.ProjectID = model.ProjectID;
                task.TeamMemberID= model.TeamMemberID;
                context.SaveChanges();
           
            }
            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id) {
            var task = context.tasks.FirstOrDefault(t => t.Id == id);
            if ( task !=null)
            {
                context.tasks.Remove(task);
                context.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        public IActionResult Add() { 
        return View();
        
        }

        [HttpPost]
        public IActionResult Add(task model) { 
        if (model.Title!=null && model.Description != null && model.Status != null && model.Priority != null)
            {
                context.tasks.Add(model);
                context.SaveChanges();
                return RedirectToAction("Index");

            }
            return View(model);
        
        
        }

        public IActionResult Details(int id) {
            var task = context.tasks.FirstOrDefault(t => t.Id == id);
            if (task != null) { 
            var teamMember=context .TeamMembers.FirstOrDefault(tm=>tm.Id== task.TeamMemberID);
                var project=context.projects.FirstOrDefault(p=>p.Id== task.ProjectID);
                var taskDetails=new TaskDetailsViewModel() { Task=task, TeamMember=teamMember, Project=project};
                return View(taskDetails);
            }
            return RedirectToAction("index");
        
        }

    }
}
