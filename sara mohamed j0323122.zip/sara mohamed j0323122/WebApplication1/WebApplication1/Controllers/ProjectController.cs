﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Build.Construction;
using System.Reflection.Metadata.Ecma335;
using WebApplication1.Models;
using WebApplication1.viewModels;

namespace WebApplication1.Controllers
{
    public class ProjectController : Controller
    {
        IATSContext context = new IATSContext();
        public IActionResult Index()
        {
            var projects = context.projects.ToList();
            return View(projects);
        }
        [HttpGet]
        public IActionResult Update(int id)
        {
            var project = context.projects.FirstOrDefault(p => p.Id == id);
            if (project != null)
            {
                return NotFound();

            }
            return View(project);
        }
        [HttpPost]
        public IActionResult Update(Project model)
        {
            var project = context.projects.FirstOrDefault(p => p.Id == model.Id);
            if (project == null)
            {
                project.Name = model.Name;
                project.Description = model.Description;
                project.StartDate = model.StartDate;
                project.EndDate = model.EndDate;
                context.SaveChanges();
                return RedirectToAction("Index");

            }
            return View(model);

        }

        public ActionResult Delete(int id) { 
        var project = context.projects.FirstOrDefault(p => p.Id == id);
            if (project == null) { 
            context.projects.Remove(project);
                context.SaveChanges();
            }
            return RedirectToAction("Index");
        }
        [HttpGet]
        public ActionResult Add(int id) { 
        return View();
        
        }

        [HttpPost]
        public IActionResult Add(Project model) { 
        if (model!=null)
            {
                context.projects.Add(model);
                context.SaveChanges();
                return RedirectToAction("Index");
            }
        return View(model);
        
        }
        //public IActionResult Details(int id) { 
        //var project =context.projects.FirstOrDefault(a=>a.Id==id);
        //    if (project == null)
        //    {
        //        var task = context.tasks.FirstOrDefault(    a=>a.ProjectID==id);
        //        var projectTask = new projecttask()
        //        {
        //            project = project,
        //            Task = task

        //        };
        //        return View(projectTask);

        //    }
        //    return RedirectToAction("Index");

        //}

        //private class projecttask
        //{
        //    public projecttask()
        //    {
        //    }

        //    public Project project { get; set; }
        //    public task Task { get; set; }
        //}
        public IActionResult Details(int id) {
        var project = context.projects.FirstOrDefault(p => p.Id==id);
            if (project == null) {
                return RedirectToAction("Index");
            }
            var tasks = context.tasks.Where(t => t.ProjectID == id).ToList();
            var projectDetails = new ProjectDetailsViewModel
            {
                Project = project,
                Tasks = tasks
            };
            return View(projectDetails);

        
        
        }
        

    } 
}
