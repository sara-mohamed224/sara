﻿using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class TeamMember
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Role {  get; set; }
        public List<Task> Tasks = new List<Task>(); 

    }
}
