﻿using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Models
{
    public class IATSContext:DbContext
    {
        public DbSet<task> tasks { get; set; }
        public DbSet<Project> projects { get; set; }
        public DbSet<TeamMember> TeamMembers { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=FS-COMLAB3-PC02;Initial Catalog=task;User ID=sa;Password=FIATS@2024;Trust Server Certificate=True");
            base.OnConfiguring(optionsBuilder);
        }
    }
}
