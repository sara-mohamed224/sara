﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models
{
    public class task
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Title { get; set; }
        public string Status { get; set; }
        public string Priority { get; set; }
        public DateTime DeadLine { get; set; }
        [ForeignKey("Project")]
        public int ProjectID { get; set; }
        public Project Project { get; set; }
        [ForeignKey("TeamMember")]
        public int TeamMemberID { get; set; }
        public TeamMember TeamMember { get; set; }
    }
}
